## ***WM8731 DRIVER SETUP***
##### ***Description**: this repository contains the implementation for the **WM8731 AUDIO CODEC** for the FRDM-K64F.*
##### ***Device information***: **WM8731** Portable Internet Audio CODEC with Headphone Driver and Programmable Sample Rates


